import type { PropsWithChildren } from 'react';
import { useTranslation } from 'react-i18next';
import { Target } from 'lucide-react';

import {
  CardSectionHeader,
  Dialog,
  DialogDescription,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/shared/ui';

type Props = PropsWithChildren<{ open: boolean; onClose: () => void }>;

export function EditTargetModal({ open, onClose, children }: Props) {
  const { t } = useTranslation('targets', {
    keyPrefix: 'edit',
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        if (!isOpen) onClose();
      }}
    >
      <DialogContent>
        <DialogHeader className="text-start">
          <CardSectionHeader
            title={t('title')}
            description={t('subtitle')}
            icon={Target}
            aria-hidden
          />
          <DialogTitle className="sr-only">{t('title')}</DialogTitle>
          <DialogDescription className="sr-only">
            {t('subtitle')}
          </DialogDescription>
        </DialogHeader>

        {children}
      </DialogContent>
    </Dialog>
  );
}
