import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import App from './App.tsx';

import './styles/index.css';

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('Unable to mount the application: #root was not found.');
}

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
