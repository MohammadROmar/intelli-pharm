import type { Permission } from '@/shared/api';

import type { PermissionGroup } from './permissionParser';

export type PermissionSelectionState = {
  selected: ReadonlySet<Permission>;
};

export type PermissionSelectionAction =
  | { type: 'toggle'; permission: Permission; group: PermissionGroup }
  | { type: 'setGroup'; permissions: readonly Permission[]; checked: boolean };

export function getViewPermissions(group: PermissionGroup): Permission[] {
  return group.actions
    .filter((parsedAction) => parsedAction.action === 'view')
    .map((parsedAction) => parsedAction.permission);
}

function allPermissionsOf(group: PermissionGroup): Permission[] {
  return group.actions.map((parsedAction) => parsedAction.permission);
}

export function permissionSelectionReducer(
  state: PermissionSelectionState,
  action: PermissionSelectionAction,
): PermissionSelectionState {
  switch (action.type) {
    case 'toggle': {
      const next = new Set(state.selected);
      const viewPermissions = getViewPermissions(action.group);
      const isViewPermission = viewPermissions.includes(action.permission);
      const isCurrentlySelected = next.has(action.permission);

      if (isCurrentlySelected) {
        next.delete(action.permission);

        const hasAnotherViewPermission = viewPermissions.some((permission) =>
          next.has(permission),
        );

        // Clear dependent actions only when no view permission remains. A
        // group can expose both `view` and `view.own`; removing one must not
        // discard the group while the other still satisfies the view gate.
        if (isViewPermission && !hasAnotherViewPermission) {
          for (const permission of allPermissionsOf(action.group)) {
            next.delete(permission);
          }
        }
      } else {
        const isViewGateSatisfied = viewPermissions.some((permission) =>
          next.has(permission),
        );

        // Keep the reducer invariant intact even if a caller bypasses the
        // disabled checkbox in the UI and dispatches directly.
        if (
          !isViewPermission &&
          viewPermissions.length > 0 &&
          !isViewGateSatisfied
        ) {
          return state;
        }

        next.add(action.permission);
      }

      return { selected: next };
    }

    case 'setGroup': {
      const next = new Set(state.selected);
      for (const permission of action.permissions) {
        if (action.checked) next.add(permission);
        else next.delete(permission);
      }
      return { selected: next };
    }

    default: {
      // If PermissionSelectionAction ever grows a new variant without a
      // matching case above, `action` stops being `never` here and this
      // line fails to compile — catches the gap at build time instead of
      // silently falling through at runtime.
      const exhaustiveCheck: never = action;
      return exhaustiveCheck;
    }
  }
}

/**
 * A non-view permission is locked until its group's view (or view.own) is
 * selected. Groups with no view action at all (erp.leaves.manage,
 * auth.roles.manage, tracking's top-level actions, ...) are never locked —
 * there's nothing to gate against.
 *
 * Takes the group's already-extracted view permissions rather than the
 * whole group, since the caller (PermissionGroupPicker) calls this once per
 * action in the group — passing the precomputed list avoids re-deriving it
 * redundantly on every one of those calls.
 */
export function isPermissionLocked(
  action: string,
  viewPermissions: readonly Permission[],
  selected: ReadonlySet<Permission>,
): boolean {
  if (action === 'view') return false;
  if (viewPermissions.length === 0) return false;

  return !viewPermissions.some((permission) => selected.has(permission));
}
