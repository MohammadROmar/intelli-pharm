import {
  useForm,
  type SubmitHandler,
  Controller,
  FormProvider,
} from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Folder, Folders } from 'lucide-react';

import { CategorySelector } from './CategorySelector';
import type { CategoryDto } from '../model/categoryTypes';
import {
  Field,
  FieldLabel,
  FormActions,
  CardSectionHeader,
  CardHeader,
  Card,
  CardContent,
  CardFooter,
} from '@/shared/ui';
import { BilingualNameFields } from '@/shared/form';

type CategoryFormProps = {
  onSubmit: SubmitHandler<CategoryDto>;
  defaultValues?: Partial<CategoryDto>;
  isLoading?: boolean;
  parentData?: { id: number; name: string };
  onReset: () => void;
};

export function CategoryForm({
  onSubmit,
  defaultValues,
  isLoading,
  parentData,
  onReset,
}: CategoryFormProps) {
  const methods = useForm<CategoryDto>({ defaultValues });
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = methods;

  const { t } = useTranslation('categories', { keyPrefix: 'form' });

  return (
    <Card>
      <CardHeader>
        <CardSectionHeader
          icon={Folders}
          title={t('info.title')}
          description={t('info.description')}
        />
      </CardHeader>

      <CardContent>
        <FormProvider {...methods}>
          <form
            id="category-form"
            onSubmit={handleSubmit(onSubmit)}
            className="space-y-5"
          >
            <BilingualNameFields
              icon={Folder}
              disabled={isLoading}
              placeholderNamespace="categories"
            />
            <Field data-invalid={!!errors.parent_id}>
              <FieldLabel asChild>
                <p>
                  {t('categoryParent')}{' '}
                  <span className="text-muted-foreground text-xs font-normal">
                    ({t('optional')})
                  </span>
                </p>
              </FieldLabel>
              <Controller
                name="parent_id"
                control={control}
                render={({ field }) => (
                  <CategorySelector
                    isLoading={isLoading}
                    invalid={!!errors.parent_id}
                    parent={parentData}
                    value={field.value}
                    onValueChange={field.onChange}
                  />
                )}
              />
            </Field>
          </form>
        </FormProvider>
      </CardContent>
      <CardFooter>
        <FormActions
          form="category-form"
          isEdit={!!defaultValues}
          isLoading={isLoading}
          onReset={onReset}
        />
      </CardFooter>
    </Card>
  );
}
