import { apiClient } from '@/shared/api';

import type {
  CreateRolePayload,
  Role,
  UpdateRolePayload,
} from '../model/roleTypes';

export function createRole(payload: CreateRolePayload) {
  return apiClient.post<Role>('/auth/v1/roles', payload);
}

export function updateRole({ id, ...payload }: UpdateRolePayload) {
  return apiClient.put<Role>(`/auth/v1/roles/${id}`, payload);
}
