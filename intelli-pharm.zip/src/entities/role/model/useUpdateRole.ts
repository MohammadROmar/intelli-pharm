import { useEditEntity } from '@/shared/model';

import { updateRole } from '../api/roleApi';
import type { UpdateRolePayload } from './roleTypes';

export function useUpdateRole() {
  return useEditEntity<UpdateRolePayload>({
    queryKey: 'roles',
    translationKey: 'roles.edit',
    redirectTo: '/dashboard/roles',
    mutationFn: updateRole,
  });
}
