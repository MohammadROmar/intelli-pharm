import { useMemo } from 'react';
import {
  Controller,
  useFormContext,
  useFormState,
  useWatch,
} from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Clock, Shield, Truck, Briefcase } from 'lucide-react';

import { getRoles } from '../lib/getRoles';
import type { EmployeeInternalFormData } from '../model/employeeTypes';
import {
  Card,
  CardContent,
  CardHeader,
  Field,
  FieldError,
  FieldLabel,
  CardSectionHeader,
  GenericSingleSelect,
  Input,
  SwitchRow,
} from '@/shared/ui';

type Props = { isLoading?: boolean };

export function EmployeeInfoCard({ isLoading }: Props) {
  const { register, getValues, control } =
    useFormContext<EmployeeInternalFormData>();
  const { errors } = useFormState<EmployeeInternalFormData>({
    name: ['role', 'is_active', 'working_start', 'working_end'],
  });

  const isDistributor = useWatch({ control, name: 'role' }) === 'distributor';

  const { t } = useTranslation('employees');
  const { t: tCommon } = useTranslation('common', { keyPrefix: 'form' });

  const roles = useMemo(() => getRoles(t), [t]);

  return (
    <Card>
      <CardHeader>
        <CardSectionHeader
          icon={Briefcase}
          title={t('form.employmentInfoTitle')}
          description={t('form.employmentInfoSubtitle')}
        />
      </CardHeader>

      <CardContent className="space-y-5">
        <Controller
          name="is_active"
          control={control}
          render={({ field }) => (
            <SwitchRow
              id="active"
              disabled={isLoading}
              label={t('form.fields.active')}
              description={t('form.activeDescription')}
              checked={field.value ?? false}
              onCheckedChange={field.onChange}
            />
          )}
        />

        <Field data-invalid={!!errors.role}>
          <FieldLabel asChild>
            <p>{t('form.fields.role')}</p>
          </FieldLabel>
          <Controller
            name="role"
            control={control}
            rules={{ required: true }}
            render={({ field }) => (
              <GenericSingleSelect
                disabled={isLoading}
                invalid={!!errors.role}
                options={roles}
                valueKey="value"
                labelKey="label"
                icon={Shield}
                value={field.value}
                onValueChange={field.onChange}
                hasMoreLabel={false}
              />
            )}
          />
          {errors.role && (
            <FieldError data-invalid={!!errors.working_start}>
              {tCommon('errors.required')}
            </FieldError>
          )}
        </Field>

        {isDistributor && (
          <Field data-invalid={!!errors.vehicle_capacity}>
            <FieldLabel htmlFor="vehicle_capacity">
              {t('form.fields.vehicleCapacity')}
            </FieldLabel>
            <Input
              id="vehicle_capacity"
              type="number"
              autoComplete="off"
              icon={Truck}
              min="0"
              placeholder="0.00"
              aria-invalid={!!errors.vehicle_capacity}
              {...register('vehicle_capacity', {
                required: true,
                disabled: isLoading,
                valueAsNumber: true,
                shouldUnregister: true,
              })}
            />
            {errors.vehicle_capacity && (
              <FieldError>{tCommon('errors.required')}</FieldError>
            )}
          </Field>
        )}

        <Field data-invalid={!!errors.working_start}>
          <FieldLabel htmlFor="working_start">
            {t('form.fields.workingStart')}
          </FieldLabel>
          <Input
            id="working_start"
            type="time"
            autoComplete="off"
            icon={Clock}
            aria-invalid={!!errors.working_start}
            {...register('working_start', {
              required: true,
              disabled: isLoading,
            })}
          />
          {errors.working_start && (
            <FieldError>{tCommon('errors.required')}</FieldError>
          )}
        </Field>

        <Field data-invalid={!!errors.working_end}>
          <FieldLabel htmlFor="working_end">
            {t('form.fields.workingEnd')}
          </FieldLabel>
          <Input
            id="working_end"
            type="time"
            autoComplete="off"
            icon={Clock}
            aria-invalid={!!errors.working_end}
            {...register('working_end', {
              required: 'errors.required',
              validate: (value) => {
                const start = getValues('working_start');
                return value > start || 'errors.endAfterStart';
              },
              disabled: isLoading,
            })}
          />
          {errors.working_end?.message && (
            <FieldError>{tCommon(errors.working_end.message)}</FieldError>
          )}
        </Field>
      </CardContent>
    </Card>
  );
}
